On obtient l'objet trajet : 
<?php echo "<br>" ?>
id : <?php  echo $context->trajet->id; echo "<br>"; ?>
depart : <?php echo $context->trajet->depart; echo "<br>";?>
arrivee : <?php echo $context->trajet->arrivee; echo "<br>";?>
distance : <?php echo $context->trajet->distance; echo "km <br>";?> 