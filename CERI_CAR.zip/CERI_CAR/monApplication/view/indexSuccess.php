C'est l'action par défaut ! 
<a href=monApplication.php?action=logout>Deconnectez vous !</a>
