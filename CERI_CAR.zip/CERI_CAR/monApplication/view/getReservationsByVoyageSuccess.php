On obtient la collection de réservations : 

<?php echo "<br>" ?>
<?php foreach($context->reservations as $reservation){ ?>
id : <?php  echo $reservation->id; echo "<br>"; ?>
voyage id : <?php echo $reservation->voyage->id ?> pour trajet : <?php echo $reservation->voyage->trajet->depart;?>--><?php echo $reservation->voyage->trajet->arrivee; echo "<br>";?> 
voyageur : <?php echo $reservation->voyageur->nom; echo "<br>";?>
<?php } ?>