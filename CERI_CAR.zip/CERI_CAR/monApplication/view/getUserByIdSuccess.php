On obtient l'objet User : 
<?php echo "<br>" ?>
id : <?php  echo $context->user->id; echo "<br>"; ?>
nom : <?php echo $context->user->nom; echo "<br>";?>
prenom : <?php echo $context->user->prenom; echo "<br>";?>
avatar : <?php echo $context->user->avatar; echo "<br>";?>
identifiant : <?php echo $context->user->identifiant; echo "<br>";?>
pass : <?php echo $context->user->pass; echo "<br>";?>