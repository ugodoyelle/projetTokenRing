On obtient la collection de voyages : 

<?php echo "<br>" ?>
<?php foreach($context->voyages as $voyage){ ?>
id : <?php  echo $voyage->id; echo "<br>"; ?>
conducteur : <?php echo $voyage->conducteur->nom; echo "<br>";?>
trajet : <?php echo $voyage->trajet->depart;?>--><?php echo $voyage->trajet->arrivee; echo "<br>";?>
tarif : <?php echo $voyage->tarif; echo "<br>";?>
nbplace : <?php echo $voyage->nbplace; echo "<br>";?>
heuredepart : <?php echo $voyage->heuredepart; echo "<br>";?>
contraintes : <?php echo $voyage->contraintes; echo "<br>";?>
<?php } ?>