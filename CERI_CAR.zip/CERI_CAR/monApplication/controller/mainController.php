<?php

class mainController
{

	public static function helloWorld($request,$context)
	{
		$context->mavariable="hello world";
		return context::SUCCESS;
	}



	public static function index($request,$context){
		
		return context::SUCCESS;
	}


	public static function getUserById($request,$context){
		$user=utilisateurTable::getUserById($request['id']); //On récupère l'utilisateur avec l'id contenu dans la requête
		if($user==false){return context::ERROR;}
		$context->user=$user; 		// on "stocke" l'utilisateur récupéré dans le contexte
		return context::SUCCESS;
	}

	public static function getUserByLoginAndPass($request,$context){
		$user=utilisateurTable::getUserByLoginAndPass($request['login'],$request['pass']);  //On récupère l'utilisateur avec le pass et le login de la requete
		if($user==false){return context::ERROR;}
		$context->user=$user;   //on stocke l'user dans le context
		return context::SUCCESS;
	}

	public static function getTrajet($request,$context){
		$trajet=trajetTable::getTrajet($request['depart'],$request['arrivee']);  // on appelle la méthode de la classe TrajetTable, pour obtenir un trajet à partir de la rêquete
		if($trajet==false){return context::ERROR;}  //Si le trajet n'existe pas, on retourne une erreur
		$context->trajet=$trajet;   //on stocke le trajet dans le context
		return context::SUCCESS; //S'il existe return success
	}


	public static function getVoyagesByTrajet($request,$context){
		if (array_key_exists('trajet', $_REQUEST)) {
			$voyages=voyageTable::getVoyagesByTrajet($request['trajet']);  // on appelle la méthode de la classe VoyageTable, pour obtenir  une collection de voyages à partir d'un trajet
			if($voyages==false){return context::ERROR;}  //Si aucun voyage n'existe pour le trajet
			$context->voyages=$voyages;   //on stocke les voyages dans le context
			return context::SUCCESS; //S'ils existent return success
		}
		else return context::ERROR;
		
	}


	public static function getReservationsByVoyage($request,$context){
		$reservations=reservationTable::getReservationsByVoyage($request['voyage']);  // on appelle la méthode de la classe reservationtable, pour obtenir  une collection de reservations à partir d'un voyage
		if($reservations==false){return context::ERROR;}  //Si aucun voyage n'existe pour le trajet
		$context->reservations=$reservations;   //on stocke les reservations dans le context
		return context::SUCCESS; //Si elles existent return success
	}


	


}
