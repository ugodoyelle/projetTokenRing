<?php 

    require_once "trajet.class.php";

    class trajetTable{

        public static function getTrajet($depart,$arrivee){
            $em = dbconnection::getInstance()->getEntityManager() ;  //On se connecte à notre base de données, en récupérant une instance de la classe dbconnection
            $trajetRepository = $em->getRepository('trajet'); //getRepository retourne la table trajet dans la base de données
            $trajet = $trajetRepository->findOneBy(array('depart' => $depart, 'arrivee' => $arrivee));	//On trouve le trajet avec un lieu de départ et d'arrivée
            if ($trajet == false){ //trajet non trouvé
                echo 'Erreur sql';
            }
            return $trajet; //on retourne le trajet trouvé (objet)
        }

    }



?>