<?php

use Doctrine\Common\Collections\ArrayCollection;
/** 
 * @Entity
 * @Table(name="jabaianb.trajet")
 */
class Trajet{
    /** @Id @Column(type="integer")
	 *  @GeneratedValue
	 */ 
	public $id;

    /** @Column(type="string",length=45) */
    public $depart;

    /** @Column(type="string",length=45) */
    public $arrivee;

    /** @Column(type="integer") */
    public $distance;


}

?>