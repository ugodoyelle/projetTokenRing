<?php 

    require_once "reservation.class.php";

    class reservationTable{

        public static function getReservationsByVoyage($voyage){
            $em = dbconnection::getInstance()->getEntityManager() ;  //On se connecte à notre base de données, en récupérant une instance de la classe dbconnection
            $reservationRepository = $em->getRepository('reservation'); //getRepository retourne la table reservation dans la base de données
            $reservations = $reservationRepository->findBy(array('voyage' => $voyage));	//On trouve les réservations associées à un voyage
            if ($reservations == false){ //trajet non trouvé
                echo 'Erreur sql';
            }
            return $reservations; //on retourne la collection de reservations associées au voyage
        }

    }



?>