<?php
// Inclusion de la classe utilisateur
require_once "utilisateur.class.php";

class utilisateurTable {

  public static function getUserByLoginAndPass($login,$pass){
		$em = dbconnection::getInstance()->getEntityManager() ;  //On se connecte à notre base de données, en récupérant une instance de la classe dbconnection

		$userRepository = $em->getRepository('utilisateur'); //getRepository retourne la table utilisateur dans la base de données
		$user = $userRepository->findOneBy(array('identifiant' => $login, 'pass' => $pass));	//On trouve l'utilisateur avec son identifiant et son Mot de passe
		//$user = $userRepository->findOneBy(array('identifiant' => $login, 'pass' => sha1($pass)));	on commente pour tester le mot de passe
		if ($user == false){ //utilisateur non trouvé
			echo 'Erreur sql';
		}
		return $user; //on retourne l'utilisateur trouvé (objet)
	}

	public static function getUserById($id){
		$em = dbconnection::getInstance()->getEntityManager(); //connexion à la base de donnée

		$userRepository = $em->getRepository('Utilisateur');  //on cherche la table Utilisateur
		$user=$userRepository->findOneBy(array('id'=>$id));  //on cherche dans cette table l'id passé en paramètre : $id

		if ($user == false){ //utilisateur non trouvé
			echo 'Erreur sql';
		}

		return $user; //on retourne l'utilisateur trouvé (objet)
	}

  
}


?>
