<?php 
require_once "voyage.class.php";

class voyageTable{

    public static function getVoyagesByTrajet($trajet){
        $em = dbconnection::getInstance()->getEntityManager() ;  //On se connecte à notre base de données, en récupérant une instance de la classe dbconnection
        $voyageRepository = $em->getRepository('voyage'); //getRepository retourne la table voyage dans la base de données
        $voyages = $voyageRepository->findBy(array('trajet' => $trajet));	//On trouve tous les voyages  associés à un trajet
        if ($voyages == false){ //aucun voyage trouvé pour le trajet
            echo 'Erreur sql';
        }
        return $voyages ; //on retourne la collection de voyages trouvés
    }
}













?>