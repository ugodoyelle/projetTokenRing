<?php
        // Nom de l'application
        $nameApp = "monApplication";

        // Action par défaut
        $action = "index";

        // Vérifie si la clé "action" existe dans la requête et la récupère
        if (key_exists("action", $_REQUEST))
            $action = $_REQUEST['action'];

        // Inclusion des fichiers de base
        require_once 'lib/core.php';
        require_once $nameApp.'/controller/mainController.php';

        // Inclusion des fichiers de modèle (tous les fichiers .class.php dans le répertoire model)
        foreach (glob($nameApp.'/model/*.class.php') as $model)
            include_once $model;

        // Démarrage de la session
        session_start();

        // Initialisation du contexte
        $context = context::getInstance();
        $context->init($nameApp);

        // Exécution de l'action demandée et récupération de la vue
        $view = $context->executeAction($action, $_REQUEST);

        // Traitement des erreurs de base, reste à traiter les erreurs d'inclusion
        if ($view === false) {
            echo "Une grave erreur s'est produite, il est probable que l'action ".$action." n'existe pas...";
            die;
        }
        // Inclusion du layout qui va lui-même inclure le template view
        elseif ($view != context::NONE) {
            $template_view = $nameApp."/view/".$action.$view.".php";
            include($nameApp."/layout/".$context->getLayout().".php");
        }

?>