<?php
class context
{
    private $data;
    const SUCCESS="Success";
    const ERROR="Error";
    const NONE="None";
    private $name;
	private $notification;
    private static $instance=null;
    private $layout;
	
	 /**
     * @return context
     */
	public static function getInstance()
	{
		if(self::$instance==null)
		  self::$instance=new context();
		return self::$instance; 
	}
	
	private function __construct()
	{
	  			
	}

	public function getNotification(){
		return $this->notification;
	}
	public function setNotification($chaine){
		$this->notification=$chaine;
	}

	public function init($name)
	{
       $this->name=$name;
       
	}
	
	public function getLayout()
	{
		 return $this->layout;
	}

	public function setLayout($layout)
	{
		$this->layout=$layout;
	}	
	
	public function redirect($url)
	{
		header("location:".$url); 
	}

	//$action contient le nom de l'action, et $request contient l'ensemble des éléments de la requête http envoyée au serveur
	public function executeAction($action,$request) 

	{
		$this->layout="layout";  //Si une action est executée alors création d'un attribut layout
		if(!method_exists('mainController',$action)) //vérifie si la méthode stockée dans $action existe pour la classe mainController
		  return false; 
		
		return  mainController::$action($request,$this); 
		//on appelle la méthode $action de la classe mainController, avec en paramètre $request (requête http) et une instance du context ($this) -> on Retourne la valeur de cette appel. (ici une constante de la classe contexte)
	}
	
	public function getSessionAttribute($attribute)
	{
		if(array_key_exists($attribute, $_SESSION))		
			return $_SESSION[$attribute];
		else
			return NULL;
	}
	
	public function setSessionAttribute($attribute,$value)
	{
		$_SESSION[$attribute]=$value;
	}
    
	
	
	public function __get($prop)
    	{
		if(array_key_exists($prop, $this->data))        	
			return $this->data[$prop];
		else
			return NULL;      
    	}
    
   	public function __set($prop,$value) 
    	{
        	$this->data[$prop]=$value;      
    	}
	
		
}
