#include "headCom.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h> 
#define MAX_ANNEAU 50
struct sockaddr_in anneau[MAX_ANNEAU] = {0};

void fatal(char*error){
    perror(error);
    exit(255);
}


void connexionServerDriver(struct sockaddr_un *serveur,int * localsock){  //Fonction pour se connecter au serveur driver en TCP en mode AF_UNIX
   
   *localsock=socket(AF_UNIX,SOCK_STREAM,0); //création de la local sock entre le driver et le com en TCP UNIX
   if (*localsock<=0) fatal("mauvais socket"); 
   bzero(serveur,sizeof(*serveur));  //on initialise à 0 la structure d'adresse 
   serveur->sun_family=AF_UNIX;  
   strcpy(serveur->sun_path, "/tmp/localSocketUnix"); // Nom du fichier de socket, on copie le chemin vers le fichier socket dans la structure de données du serveur 
   if (connect(*localsock, (struct sockaddr *)serveur, sizeof(struct sockaddr_un)) == -1) {//connexion au serveur en mode tcp;
      fatal("Erreur de connexion au serveur");
      exit(1);
   }


}

void deconnexionServerDriver(int * localsock){
   close(localsock);
}



int insertionDansAnneau(int * localsock){
   char choix[25];
   int choix2;
   int Tabindices[50];
   int portTemp;
   int k=0;
   memset(Tabindices,0,50);
   memset(choix, '0', 50); 
   printf("Voulez-vous vous intégrer à l'anneau ? (O/n) : \n");
   if((scanf("%s",choix))!=1){
      while(scanf("%s",choix)!=1){
         printf("veuillez saisir (O) pour oui et (n) pour Non");
      }
   }
   if (choix[0]=='O')
   {
       char message[10]="connexion";
       ssize_t bytes_sent = send(localsock, message, strlen(message), 0);
       if (bytes_sent == -1) {
           perror("Erreur lors de l'envoi de la demande de connexion dans l'anneau");
       } else {
           printf("Demande connexion dans l'anneau Envoyée avec succès %zd octets : %s\n", bytes_sent, message);
       }
   }
}


int main(int argc, char const *argv[])
{
   int localsockCom;
   struct sockaddr_un serveur;
   connexionServerDriver(&serveur,&localsockCom);
   close(localsockCom);
   return 0;
}
        