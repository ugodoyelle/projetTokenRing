#ifndef HEADCOM_H
#define HEADCOM_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netdb.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h>
#include <arpa/inet.h>

#define MAX_CLIENTS 50

extern struct sockaddr_in anneau[MAX_CLIENTS]= {0};


void connexionServerDriver(struct sockaddr_un *serveur, int *localsock);

void fatal(char*error);

#endif