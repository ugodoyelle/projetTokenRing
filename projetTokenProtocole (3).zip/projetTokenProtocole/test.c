#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>

#define UNIX_SOCKET_PATH "localSocketUnix"
#define TCP_PORT 8080

void handle_error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main() {
    // Create and bind Unix domain socket
    int unix_socket = socket(AF_UNIX, SOCK_STREAM, 0);
    if (unix_socket == -1) {
        handle_error("Error creating Unix domain socket");
    }

    struct sockaddr_un unix_addr;
    memset(&unix_addr, 0, sizeof(unix_addr));
    unix_addr.sun_family = AF_UNIX;
    strcpy(unix_addr.sun_path, UNIX_SOCKET_PATH);
    
    if (bind(unix_socket, (struct sockaddr *)&unix_addr, sizeof(unix_addr)) == -1) {
        handle_error("Error binding Unix domain socket");
    }

    // Create and bind IPv4 socket
    int inet_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (inet_socket == -1) {
        handle_error("Error creating IPv4 socket");
    }

    struct sockaddr_in inet_addr;
    memset(&inet_addr, 0, sizeof(inet_addr));
    inet_addr.sin_family = AF_INET;
    inet_addr.sin_port = htons(TCP_PORT);
    inet_addr.sin_addr.s_addr = INADDR_ANY;
    int test=sizeof(inet_addr);
    printf("test taille : %d\n",inet_addr.sin_addr.s_addr);
    if (bind(inet_socket, (struct sockaddr *)&inet_addr, sizeof(inet_addr)) == -1) {
        handle_error("Error binding IPv4 socket");
    }

    // Rest of your code...

    return 0;
}
 