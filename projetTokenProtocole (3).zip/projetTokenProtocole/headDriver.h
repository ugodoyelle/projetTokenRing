#ifndef HEADDRIVER_H
#define HEADDRIVER_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netdb.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h>


#include <arpa/inet.h>

#define MAX_CLIENTS 50

extern struct sockaddr_in anneau[MAX_CLIENTS];


void startDriver(struct sockaddr_un *serveurDriverU, struct sockaddr_un *clientlocal, struct sockaddr_in *serv, struct sockaddr_in *clientinet, struct hostent *hp, int *acceptls, int *localsock, int *anneausockd, int *anneausockg, int *acceptinet);
void fatal(char*error);

// Définition de la structure de jeton
typedef struct {
    char name[50];
} Token;

#endif  // Fin des gardes d'inclusion
