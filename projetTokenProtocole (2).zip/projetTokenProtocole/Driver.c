#include "headDriver.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h>
#include <time.h>
#define UNIX_SOCKET_PATH "localSocketUnix"


int PORT[50];

void fatal(char*error){
    perror(error);
    exit(255);
}


void connexionAuClientComm(struct sockaddr_un * serveurDriverU,struct sockaddr_un * clientlocal,struct sockaddr_in * serv,struct sockaddr_in * clientinet,struct hostent * hp,int*acceptls,int*localsock,int*anneausockd,int*anneausockg,int *acceptinet){
    int cc;
    int compteur = 1;
    int randomPort; 
    int plage = 65535 - 49152 + 1;
    srand((unsigned int)time(NULL));  //génération d'un port aléatoire
    randomPort= rand() % plage + 49152;

    char nom[50];
    cc=gethostname(nom,sizeof(nom));
    if(cc==-1){
        fatal("erreur gethostname\n");
    }
    hp=gethostbyname(nom);
    if(hp==NULL){
        fatal("erreur gethostbyname \n");
    }


    while(compteur!=0){
        compteur=0;
        for (int i = 0; i < 50; ++i) {  // on cherche dans le tableau le seul port client qui n'a pas été déjà attribué à un serveur
            if (randomPort==PORT[i]){  //si le port généré aléatoirement est déjà présent dans le tableau on en regénère un autre et on repars sur un tour de boucle while en sortant du for
                compteur++;
                srand((unsigned int)time(NULL));
                randomPort= rand() % plage + 49152;
                break;        
            }
        }
    }
    int k=0;
    while(PORT[k]!=0){
        k++;
    }
    PORT[k]=randomPort;
    (*serv).sin_family=AF_INET; //socket locale
    serv->sin_port = htons(PORT[k]);
    (*serveurDriverU).sun_family = AF_UNIX;
    strcpy(serveurDriverU->sun_path, UNIX_SOCKET_PATH);
    memcpy(&(serv->sin_addr), hp->h_addr, hp->h_length); // on copie la structure hp dans celle du serveur de type sockaddr_in

    *acceptls=socket(AF_UNIX,SOCK_STREAM,0); // on crée la socket d'acceptation locale
    *acceptinet=socket(AF_INET,SOCK_STREAM,0); //on crée la socket d'acceptation pour la communication avec des clients distants
    if(*acceptinet==-1){
         fatal("erreur creation socket \n");
    }
    if(*acceptls==-1){
        fatal("erreur creation socket \n");
    }

    int test=sizeof(*serv);
    cc=bind(*acceptinet,(struct sockaddr *)serv,sizeof(*serv));  //on l'attache au serveur 
    
    if(cc==-1){
        fatal("erreur bind \n");
    }
    cc=bind(*acceptls,(struct sockaddr *)serveurDriverU,sizeof(*serveurDriverU));  //on l'attache au serveur 
    if(cc==-1){
        fatal("erreur bind \n");
    }

    cc=listen(*acceptls,5); //ecoute socket local
    cc=listen(*acceptinet,5); //ecoute sur socket anneau
    if(cc==-1){
        fatal("erreur listen \n");
    }
    
    fd_set fd; //masque pour les descripteurs de sockets
    fd_set fdm; //masque de sauvegarde

    FD_ZERO(&fd); //initialisation à 0
    FD_ZERO(&fdm);  //pareil pour le masque de sauvegarde
    FD_SET(*acceptls,&fd);
    FD_SET(*acceptinet,&fd);
    bcopy(&fd,&fdm,sizeof(&fd)); //sauvegarde de fd
    while(1){
        cc=select(32, &fd, NULL, NULL, NULL); //on selectionne les sockets sur lequels effectuer une ecoute simultanée en lecture
        if(cc==-1){
            fatal("erreur select \n");
        }

        if(FD_ISSET(*acceptls,&fd)){  //si il y a une demande de connexion sur socket local
            socklen_t  lg=sizeof(*clientlocal);
            *localsock=accept(*acceptls,(struct sockaddr *)&clientlocal,&lg); //on accepte la connexion sur le socket local
            if(*localsock==-1){
                fatal("erreur accept local \n");
            }
            bcopy(&fdm,&fd,sizeof(&fd));
            FD_SET(*localsock,&fd);
            bcopy(&fd,&fdm,sizeof(&fd));
        }


        if(FD_ISSET(*acceptinet,&fd)){
            socklen_t  lginet=sizeof(*clientinet);
            *anneausockg=accept(*acceptinet,(struct sockaddr *)&clientinet,&lginet); //on accepte la connexion sur le socketfg 
            if(*anneausockg==-1){
                fatal("erreur accept anneausockg \n");
            }
        }
        
    }
}


void main(int argc,char **argv){

   
//-------------------------------------------------Main du Driver (Serveur)------------------------------------------------------------------------------------

    int acceptls,localsock,anneausockd,anneausockg,acceptinet; //On commence par définir 5 sockets, les trois sockets d'écoute en tcp -> deux de type af_inet et une af_unix qui communique avec comm
    localsock=acceptls=anneausockd=anneausockg=acceptinet=0;   //Les deux sockets restantes sont les sockets d'acceptation de connexion , une pour les af_unix et une af_inet
    int cc,indice;
    int client_sockets[50];  
    memset(client_sockets, 0, 50);  //initialisation à 0
    struct hostent * hp;
    struct sockaddr_in serv,clientinet;  //structures d'adresses de Driver et le reste de l'anneau en inet
    struct sockaddr_un serveurDriverU,clientlocal; //structures d'adresses de Driver et Com en Unix
    memset(&serveurDriverU, 0, sizeof(serveurDriverU));
    memset(&serv, 0, sizeof(serv));
    connexionAuClientComm(&serveurDriverU,&clientlocal,&serv,&clientinet,hp,&acceptls,&localsock,&anneausockd,&anneausockg,&acceptinet);

    
}