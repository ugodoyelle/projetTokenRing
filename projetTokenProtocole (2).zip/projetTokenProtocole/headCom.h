#ifndef HEADCOM_H
#define HEADCOM_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netdb.h>
#include <string.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h>



void connexionServerDriver(struct sockaddr_un *serveur, struct hostent **hpone, int *localsock);

void fatal(char*error);

#endif