#include "headCom.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h> 

int PORT[50];

void fatal(char*error){
    perror(error);
    exit(255);
}


void connexionServerDriver(struct sockaddr_un *serveur,struct hostent ** hpone,int * localsock){  //Fonction pour se connecter au serveur driver en TCP
   
   char bufo[20];
   printf("Veuillez rentrer l'adresse du serveur ou son nom de domaine\n");

   scanf("%s",bufo);  //On récupère l'adresse du serveur auquel se connecter
   printf("test\n");
   *hpone=gethostbyname(bufo); // on obtient les infos réseau du serveur avec son nom de domaine
   if (*hpone==(struct hostent *)0) fatal("machine cible non connue!");  //si aucun serveur trouvé
   *localsock=socket(AF_UNIX,SOCK_STREAM,0); //création de la local sock entre le driver et le com en TCP UNIX
   if (localsock<=0) fatal("mauvais socket"); 
   bzero(&serveur,sizeof(serveur));  //on initialise à 0 la structure d'adresse 
   serveur->sun_family=AF_UNIX;  
   strcpy(serveur->sun_path, "localSocketUnix"); // Nom du fichier de socket, on copie le chemin vers le fichier socket dans la structure de données du serveur 
   if (connect(*localsock, (struct sockaddr *)&serveur, sizeof(struct sockaddr)) == -1) {//connexion au serveur en mode tcp;
      perror("Erreur de connexion au serveur");
      exit(1);
   }

}


int main(int argc, char const *argv[])
{
   int localsockCom;
   struct sockaddr_un serveur;
   struct hostent * hpone;
   connexionServerDriver(&serveur,&hpone,&localsockCom);
   printf("test\n");
   close(localsockCom);
   unlink("localSocketUnix");
   return 0;
}
        