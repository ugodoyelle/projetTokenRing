#include "head.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <errno.h>
void fatal(char*error){
    perror(error);
    exit(255);
}


void connexionAuClientComm(struct sockaddr_un * serveurDriverU,struct sockaddr_un * clientlocal,struct sockaddr_in * serv,struct sockaddr_in * clientinet,hostent * hp,sock_t &acceptls,sock_t &localsock,sock_t &anneausockd,sock_t &anneausockg,sock_t &acceptinet){
    int cc;
    cc=gethostname(hp->name,sizeof(hp->name));
    if(cc==-1){
        fatal("erreur gethostname\n");
    }
    hp=gethostbyname(hp->name);
    if(hp==-1){
        fatal("erreur gethostbyname \n");
    }
    for (int i = 0; i < 50; ++i) {  // on cherche dans le tableau le seul port client qui n'a pas été déjà attribué à un serveur
        int compteur = 0;
        // Vérifier si l'élément est présent dans le reste du tableau
        for (int j = 0; j < 50; ++j) {
            if (i != j && PORT[i] == PORT[j]) {
                compteur++;
                break;  // Sortir du deuxième boucle dès qu'une occurrence est trouvée
            }
        }

        // Si le compteur est toujours 0, alors c'est une occurrence unique
        if (compteur == 0) {
            indice=i;
        }
    }
    serv.sin_family=AF_INET; //socket locale
    serv.sin_PORT=PORT[indice];  
    serveurDriverU.sun_family = AF_UNIX;
    cc=strcpy(serveurDriverU.sun_path, "localSocketUnix"); //Chemin du fichier socket Unix --> dans structure serveur
    if(cc==-1){
        fatal("erreur strcpy  \n");
    }
    cc=bzero(serv,sizeof(serv));
    if(cc==-1){
        fatal("erreur bzero  \n");
    }

    cc=bzero(serveurDriverU,sizeof(serveurDriverU));
    if(cc==-1){
        fatal("erreur bzero  \n");
    }
    cc=bcopy(hp->addr,serv->sin_addr,hp->h_length);  // on copie la structure hp dans celle du serveur de type sockaddr_in
    if(cc==-1){
        fatal("erreur bcopy \n");
    }

    cc=bcopy(hp->addr,serveurDriverU->sun_addr,hp->h_length);  // on copie la structure hp dans celle du serveur de type sockaddr_un
    if(cc==-1){
        fatal("erreur bcopy \n");
    }

    acceptls=socket(AF_UNIX,SOCK_STREAM,0); // on crée la socket d'acceptation locale
    acceptinet=socket(AF_INET,SOCK_STREAM,0); //on crée la socket d'acceptation pour la communication avec des clients distants
    if(acceptls==-1){
        fatal("erreur creation socket \n");
    }
    cc=bind(acceptls,(struct sockaddr *)&serv,sizeof(serv));  //on l'attache au serveur 
    if(cc==-1){
        fatal("erreur bind \n");
    }

    cc=bind(acceptinet,(struct sockaddr *)&serv,sizeof(serv));  //on l'attache au serveur 
    if(cc==-1){
        fatal("erreur bind \n");
    }

    cc=listen(acceptls,5); //ecoute socket local
    cc=listen(acceptinet,5); //ecoute sur socket anneau
    if(cc==-1){
        fatal("erreur listen \n");
    }
    
    fd_set fd; //masque pour les descripteurs de sockets
    fd_set fdm; //masque de sauvegarde

    FD_ZERO(&fd); //initialisation à 0
    FD_ZERO(&fm);  //pareil pour le masque de sauvegarde
    FD_SET(acceptls,&fd);
    FD_SET(acceptinet,&fd);

    bcopy(&fd,&fdm,sizeof(&fd)); //sauvegarde de fd
    while(1){
        cc=select(32, &fd, NULL, NULL, NULL); //on selectionne les sockets sur lequels effectuer une ecoute simultanée en lecture
        if(cc==-1){
            fatal("erreur select \n");
        }

        if(FD_ISSET(acceptls,&fd)){  //si il y a une demande de connexion sur socket local
            size_t lg=sizeof(clientlocal);
            localsock=accept(acceptls,(struct sockaddr *)&clientlocal,&lg); //on accepte la connexion sur le socket local
            if(localsock==-1){
                fatal("erreur accept local \n");
            }
            bcopy(&fdm,&fd,sizeof(&fd));
            FD_SET(localsock,&fd);
            bcopy(&fd,&fdm,sizeof(&fd));
        }


        if(FD_ISSET(acceptinet,&fd)){
            size_t lginet=sizeof(clientinet);
            anneausockg=accept(acceptinet,(struct sockaddr *)&clientinet,lginet); //on accepte la connexion sur le socketfg 
            if(anneausockg==-1){
                fatal("erreur accept anneausockg \n");
            }
        }
        
    }
}

void main(int argc,char **argv){

   

    sock_t acceptls,localsock,anneausockd,anneausockg,acceptinet; //On commence par définir 5 sockets, les trois sockets d'écoute en tcp -> deux de type af_inet et une af_unix qui communique avec comm
    localsock=acceptls=anneausockd=anneausockg=acceptinet=0;   //Les deux sockets restantes sont les sockets d'acceptation de connexion , une pour les af_unix et une af_inet
    int cc,indice;
    int client_sockets[50];  
    memset(client_sockets, 0, 50);  //initialisation à 0
    struct hostent * hp;
    struct sockaddr_in serv,clientinet;  //structures d'adresses de Driver et le reste de l'anneau en inet
    struct sockaddr_un serveurDriverU,clientlocal; //structures d'adresses de Driver et Com en Unix
    connexionAuClientComm(serveurDriverU,clientlocal,serv,clientinet,hp,acceptls,localsock,anneausockd,anneausockg,acceptinet);
    
    

}