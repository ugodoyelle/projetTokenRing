#ifndef HEAD_H
#define HEAD_H

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netdb.h>
// Déclaration et initialisation du tableau PORT
extern int PORT[50];
#define INIT_PORT() for(int i=0; i<50; i++) PORT[i]=0

void connexionServerDriver(struct sockaddr_un *serveur, struct hostent ** hpone, int * localsock);
void connexionAuClientComm(struct sockaddr_un * serveurDriverU,struct sockaddr_un * clientlocal,struct sockaddr_in * serv,struct sockaddr_in * clientinet,hostent * hp,sock_t &acceptls,sock_t &localsock,sock_t &anneausockd,sock_t &anneausockg,sock_t &acceptinet);

// Définition de la structure de jeton
typedef struct {
    char* name;
} Token;

#endif  // Fin des gardes d'inclusion
